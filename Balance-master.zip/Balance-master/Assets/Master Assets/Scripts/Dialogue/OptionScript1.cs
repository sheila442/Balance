﻿using UnityEngine;

public class OptionScript1 : MonoBehaviour {
    [SerializeField]
    private OptionScript os;
    private void Update()
    {
        if (Input.GetButtonDown("Dialogue Option 1 P1")) // if player1 press '1'
        {
            os.OnPointerDown();
        }

        if (Input.GetButtonDown("Dialogue Option 1 P2")) // if player2 press '1'
        {
            os.OnPointerDown();
        }
    }
}
