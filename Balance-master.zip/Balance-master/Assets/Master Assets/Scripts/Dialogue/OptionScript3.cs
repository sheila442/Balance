﻿using UnityEngine;

public class OptionScript3 : MonoBehaviour {
    [SerializeField]
    private OptionScript os;
    private void Update()
    {
        if (Input.GetButtonDown("Dialogue Option 3 P1")) // if player1 press '3'
        {
            os.OnPointerDown();
        }

        if (Input.GetButtonDown("Dialogue Option 3 P2")) // if player2 press '3'
        {
            os.OnPointerDown();
        }
    }
}
